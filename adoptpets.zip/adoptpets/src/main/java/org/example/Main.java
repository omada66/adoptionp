package org.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    // Δημιουργία λιστών για αποθήκευση δεδομένων
    private static List<Animal> animals = new ArrayList<>(); // Εγκεκριμένα ζώα
    private static List<Animal> pendingAnimals = new ArrayList<>(); // Ζώα προς έγκριση
    private static List<User> users = new ArrayList<>();

    private static final String DB_URL = "jdbc:sqlite:adoption_system.db";

    public static void main(String[] args) {
        setupDatabase(); // Δημιουργία βάσης δεδομένων
        loadAnimalsFromDatabase(); // Φόρτωση ζώων από τη βάση

        // Προσθήκη ενός παραδείγματος ζώου στις εκκρεμότητες
        pendingAnimals.add(new Animal("Bella", "Σκύλος", 3, "Υγιής"));

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        // Αρχικό μήνυμα
        System.out.println("Καλώς ήρθατε στην Πλατφόρμα Υιοθεσίας!");

        // Αρχική δοκιμαστική προσθήκη διαχειριστή και καταφυγίου
        users.add(new Admin("admin", "admin123"));
        users.add(new Shelter("shelter1", "shelter123"));

        while (running) {
            System.out.println("\nΕπιλέξτε μια ενέργεια:");
            System.out.println("1. Σύνδεση");
            System.out.println("2. Προβολή ζώων");
            System.out.println("3. Έξοδος");
            System.out.print("Επιλογή: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Καθαρισμός buffer

            switch (choice) {
                case 1:
                    login(scanner);
                    break;
                case 2:
                    displayAnimals();
                    break;
                case 3:
                    running = false;
                    System.out.println("Έξοδος από την πλατφόρμα. Ευχαριστούμε!");
                    break;
                default:
                    System.out.println("Μη έγκυρη επιλογή. Προσπαθήστε ξανά.");
            }
        }

        scanner.close();
    }

    // Μέθοδος για σύνδεση χρήστη
    private static void login(Scanner scanner) {
        System.out.print("Όνομα χρήστη: ");
        String username = scanner.nextLine();
        System.out.print("Κωδικός: ");
        String password = scanner.nextLine();

        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                System.out.println("Καλώς ήρθατε, " + username + "!");
                if (user instanceof Admin) {
                    adminMenu(scanner, (Admin) user);
                } else if (user instanceof Shelter) {
                    shelterMenu(scanner, (Shelter) user);
                }
                return;
            }
        }

        System.out.println("Λάθος όνομα χρήστη ή κωδικός.");
    }

    // Μέθοδος για εμφάνιση εγκεκριμένων ζώων
    private static void displayAnimals() {
        if (animals.isEmpty()) {
            System.out.println("Δεν υπάρχουν διαθέσιμα ζώα προς υιοθεσία.");
        } else {
            System.out.println("Διαθέσιμα ζώα:");
            for (Animal animal : animals) {
                System.out.println(animal);
            }
        }
    }

    // Μενού διαχειριστή
    private static void adminMenu(Scanner scanner, Admin admin) {
        boolean adminRunning = true;

        while (adminRunning) {
            System.out.println("\nΔιαχειριστικό Μενού:");
            System.out.println("1. Έγκριση ζώων");
            System.out.println("2. Έξοδος από το διαχειριστικό μενού");
            System.out.print("Επιλογή: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Καθαρισμός buffer

            switch (choice) {
                case 1:
                    approveAnimals();
                    break;
                case 2:
                    adminRunning = false;
                    break;
                default:
                    System.out.println("Μη έγκυρη επιλογή. Προσπαθήστε ξανά.");
            }
        }
    }

    // Μέθοδος για έγκριση ζώων
    private static void approveAnimals() {
        if (pendingAnimals.isEmpty()) {
            System.out.println("Δεν υπάρχουν ζώα προς έγκριση.");
        } else {
            System.out.println("Ζώα προς έγκριση:");
            for (int i = 0; i < pendingAnimals.size(); i++) {
                System.out.println((i + 1) + ". " + pendingAnimals.get(i));
            }

            System.out.print("Επιλέξτε αριθμό ζώου για έγκριση (ή 0 για ακύρωση): ");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();
            scanner.nextLine(); // Καθαρισμός buffer

            if (choice > 0 && choice <= pendingAnimals.size()) {
                Animal approvedAnimal = pendingAnimals.remove(choice - 1);
                animals.add(approvedAnimal);
                saveAnimalToDatabase(approvedAnimal);
                System.out.println("Το ζώο εγκρίθηκε: " + approvedAnimal);
            } else {
                System.out.println("Ακυρώθηκε η ενέργεια.");
            }
        }
    }

    // Μενού καταφυγίου
    private static void shelterMenu(Scanner scanner, Shelter shelter) {
        boolean shelterRunning = true;

        while (shelterRunning) {
            System.out.println("\nΜενού Καταφυγίου:");
            System.out.println("1. Προσθήκη ζώου");
            System.out.println("2. Έξοδος από το μενού καταφυγίου");
            System.out.print("Επιλογή: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Καθαρισμός buffer

            switch (choice) {
                case 1:
                    addPendingAnimal(scanner, shelter);
                    break;
                case 2:
                    shelterRunning = false;
                    break;
                default:
                    System.out.println("Μη έγκυρη επιλογή. Προσπαθήστε ξανά.");
            }
        }
    }

    // Μέθοδος για προσθήκη ζώου από καταφύγιο
    private static void addPendingAnimal(Scanner scanner, Shelter shelter) {
        System.out.print("Όνομα ζώου: ");
        String name = scanner.nextLine();
        System.out.print("Είδος: ");
        String species = scanner.nextLine();
        System.out.print("Ηλικία: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Καθαρισμός buffer

        System.out.print("Κατάσταση Υγείας: ");
        String healthStatus = scanner.nextLine();

        Animal newAnimal = new Animal(name, species, age, healthStatus);
        pendingAnimals.add(newAnimal);
        System.out.println("Το ζώο προστέθηκε στις εκκρεμότητες για έγκριση: " + newAnimal);
    }

    private static void setupDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            if (conn != null) {
                Statement stmt = conn.createStatement();
                // Διαγραφή του πίνακα αν υπάρχει
                stmt.execute("DROP TABLE IF EXISTS animals;");
                // Δημιουργία του πίνακα
                String sql = "CREATE TABLE IF NOT EXISTS animals (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT NOT NULL," +
                        "species TEXT NOT NULL," +
                        "age INTEGER NOT NULL," +
                        "health_status TEXT NOT NULL);";
                stmt.execute(sql);
            }
        } catch (SQLException e) {
            System.out.println("Error setting up database: " + e.getMessage());
        }
    }

    private static void saveAnimalToDatabase(Animal animal) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            String sql = "INSERT INTO animals (name, species, age, health_status) VALUES (?, ?, ?, ?);";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, animal.getName());
            pstmt.setString(2, animal.getSpecies());
            pstmt.setInt(3, animal.getAge());
            pstmt.setString(4, animal.getHealthStatus());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error saving animal to database: " + e.getMessage());
        }
    }

    private static void loadAnimalsFromDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            String sql = "SELECT name, species, age, health_status FROM animals;";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String name = rs.getString("name");
                String species = rs.getString("species");
                int age = rs.getInt("age");
                String healthStatus = rs.getString("health_status");
                animals.add(new Animal(name, species, age, healthStatus));
            }
        } catch (SQLException e) {
            System.out.println("Error loading animals from database: " + e.getMessage());
        }
    }
}

// Κλάση Animal
class Animal {
    private String name;
    private String species;
    private int age;
    private String healthStatus;

    public Animal(String name, String species, int age, String healthStatus) {
        this.name = name;
        this.species = species;
        this.age = age;
        this.healthStatus = healthStatus;
    }

    public String getName() {
        return name;
    }

    public String getSpecies() {
        return species;
    }

    public int getAge() {
        return age;
    }

    public String getHealthStatus() {
        return healthStatus;
    }

    @Override
    public String toString() {
        return "Όνομα: " + name + ", Είδος: " + species + ", Ηλικία: " + age + ", Κατάσταση Υγείας: " + healthStatus;
    }
}

// Βασική κλάση User
abstract class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

// Κλάση Admin
class Admin extends User {
    public Admin(String username, String password) {
        super(username, password);
    }
}
// Κλάση Shelter
class Shelter extends User {
    public Shelter(String username, String password) {
        super(username, password);
    }
}
