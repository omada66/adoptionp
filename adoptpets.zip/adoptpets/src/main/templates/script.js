let currentUser = null; // Θα αποθηκεύσουμε τον τρέχοντα χρήστη εδώ
let animals = [];

// Εμφάνιση της φόρμας εγγραφής
function showRegister() {
    document.getElementById("register-form").style.display = "block";
    document.getElementById("login-form").style.display = "none";
    document.getElementById("animals-list").style.display = "none";
}

// Απόκρυψη φόρμας εγγραφής
function hideRegisterForm() {
    document.getElementById("register-form").style.display = "none";
}

// Εμφάνιση της φόρμας σύνδεσης
function showLogin() {
    document.getElementById("login-form").style.display = "block";
    document.getElementById("register-form").style.display = "none";
    document.getElementById("animals-list").style.display = "none";
}

// Απόκρυψη της φόρμας σύνδεσης
function hideLoginForm() {
    document.getElementById("login-form").style.display = "none";
}

// Φόρτωση διαθέσιμων ζώων
function viewAnimals() {
    fetch('/api/animals')
        .then(response => response.json())
        .then(data => {
            animals = data;
            displayAnimals();
        })
        .catch(error => {
            console.error('Σφάλμα στην φόρτωση ζώων:', error);
        });
}

// Εμφάνιση των ζώων
function displayAnimals() {
    const animalListDiv = document.getElementById("animal-list");
    animalListDiv.innerHTML = ""; // Καθαρισμός της λίστας

    if (animals.length === 0) {
        animalListDiv.innerHTML = "<p>Δεν υπάρχουν διαθέσιμα ζώα προς υιοθεσία.</p>";
    } else {
        animals.forEach((animal, index) => {
            const animalDiv = document.createElement("div");
            animalDiv.innerHTML = `
                <p><strong>Όνομα:</strong> ${animal.name}</p>
                <p><strong>Είδος:</strong> ${animal.species}</p>
                <p><strong>Ηλικία:</strong> ${animal.age}</p>
                <p><strong>Κατάσταση Υγείας:</strong> ${animal.healthStatus}</p>
                <button onclick="adoptAnimal(${index})">Υιοθεσία</button>
            `;
            animalListDiv.appendChild(animalDiv);
        });
    }

    document.getElementById("animals-list").style.display = "block";
}

// Υιοθέτηση ζώου
function adoptAnimal(index) {
    const adoptedAnimal = animals.splice(index, 1)[0];
    alert(`Το ζώο ${adoptedAnimal.name} υιοθετήθηκε με επιτυχία!`);
    displayAnimals();
}

// Διαχείριση φόρμας εγγραφής
document.getElementById("register").addEventListener("submit", function (e) {
    e.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    const user = { username, password, role };

    // Προσομοίωση αποθήκευσης χρήστη (σε μια πραγματική εφαρμογή θα αποθηκευτεί στην βάση)
    alert("Εγγραφή ολοκληρώθηκε ως " + role);
    localStorage.setItem("user", JSON.stringify(user)); // Αποθήκευση στον τοπικό αποθηκευτικό χώρο

    currentUser = user;
    hideRegisterForm();
    if (role === 'customer') {
        viewAnimals();
    }
});

// Διαχείριση φόρμας σύνδεσης
document.getElementById("login").addEventListener("submit", function (e) {
    e.preventDefault();

    const username = document.getElementById("username-login").value;
    const password = document.getElementById("password-login").value;

    // Προσομοίωση σύνδεσης χρηστών (σε μια πραγματική εφαρμογή θα γίνει API call)
    const savedUser = JSON.parse(localStorage.getItem("user"));

    if (savedUser && savedUser.username === username && savedUser.password === password) {
        alert("Επιτυχής σύνδεση ως " + savedUser.role);
        currentUser = savedUser;

        if (currentUser.role === 'admin') {
            // Εδώ θα μπορούσες να προσθέσεις το admin μενού
            alert("Σύνδεση ως διαχειριστής");
        } else {
            viewAnimals();
        }
    } else {
        alert("Λάθος όνομα χρήστη ή κωδικός.");
    }
});